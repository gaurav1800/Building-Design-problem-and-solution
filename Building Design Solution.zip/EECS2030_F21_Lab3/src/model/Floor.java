package model;

public class Floor {
	private int size;
	private int utilizedSpace;
	private int numberOfUnits; // number of units
	private final int maxUnits = 20;
	
	private String finalString;

	private Unit[] units;
	
	
	
	public Floor() {
		//do nothing; just to initialize the variables into their default values
	}
	
	
	public Floor(int size ) {
		this.size = size;
		units = new Unit[maxUnits];
	}
	
	public Floor(Floor floor) {
		this.size = floor.size;
		this.numberOfUnits = floor.numberOfUnits;
		this.units = new Unit[maxUnits];
		for(int i = 0; i < this.numberOfUnits; i++) {
			this.units[i] = new Unit(floor.units[i]);
		}
	}
	
	public void addUnit(Unit unit) {
		int area = unit.getArea();
		if ((utilizedSpace + area) > this.size) {
			throw new InsufficientFloorSpaceException();
		}
		utilizedSpace += area;
		units[numberOfUnits] = new Unit(unit);
		numberOfUnits++;
	}
	
	public void addUnit(String function, int width, int length) {
		int area = width * length;
		if ((utilizedSpace + area) > this.size) {
			throw new InsufficientFloorSpaceException();
		}
		utilizedSpace += area;
		units[numberOfUnits] = new Unit(function, width, length);
		numberOfUnits++;
	}
	
	public String toString() {
		if (utilizedSpace > this.size) {
			throw new InsufficientFloorSpaceException();
		}
	
		if (utilizedSpace == 0) {
			finalString = "Floor's utilized space is " + utilizedSpace + " sq ft (" + (this.size - utilizedSpace)
					+ " sq ft remaining): []";
		} 
		else {
			finalString = "Floor's utilized space is " + utilizedSpace + " sq ft (" + (this.size - utilizedSpace)
					+ " sq ft remaining): [";
			for (int i = 0; i < numberOfUnits; i++) {
				if (i != 0) {
					finalString += ", ";
				}
				finalString += units[i].getFunction() + ": " + units[i].getSize() + " sq ft (" + units[i].getWidth()
						+ "' by " + units[i].getLength() + "')";
			}
			finalString += "]";
		}
		return finalString;
	}
	
	public boolean equals(Object obj) {
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Floor other = (Floor) obj;
		if (this.size != other.size || this.numberOfUnits != other.numberOfUnits) {
			return false;
		}
	
		Floor remainingOtherUnits = new Floor(other.size);
		boolean isEqual = true;
		for (int x = 0; x < other.numberOfUnits; x++) {
			remainingOtherUnits.addUnit(other.units[x]);
		}
		for (int x = 0; x < this.numberOfUnits && isEqual; x++) {
			boolean unitFound = false;
			for (int y = 0; y < other.numberOfUnits; y++) {
				if (this.units[x].equals(remainingOtherUnits.units[y])) {
					remainingOtherUnits.units[y] = null;
					unitFound = true;
					break;
				}
			}
			if (!unitFound) {
				isEqual = false;
				break;
			}
		}
		return isEqual;
	}

}










