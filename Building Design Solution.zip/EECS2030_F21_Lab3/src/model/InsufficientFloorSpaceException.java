package model;

public class InsufficientFloorSpaceException extends RuntimeException{
	
	public InsufficientFloorSpaceException() {
		super();
	}

}
