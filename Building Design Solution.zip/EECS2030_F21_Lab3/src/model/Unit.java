package model;

public class Unit {
	private String function;
	private String finalString;

	private int width;
	private int length;

	private double widthinm; // width in meters
	private double lengthinm; // length in meters

	private boolean inMeters;
	private boolean inFeet;

	public Unit() {
		// do nothing; just to initialize the variables with their default values
	}

	public Unit(String function, int width, int length) {
		this.function = function;
		this.width = width;
		this.length = length;

		inMeters = false;
		inFeet = true;

	}

	public Unit(Unit unit) {
		this.function = unit.function;
		this.width = unit.width;
		this.length = unit.length;

		inMeters = false;
		inFeet = true;

	}

	public String getFunction() {
		return this.function;
	}

	public int getWidth() {
		return this.width;
	}

	public int getArea() {
		return this.width * this.length;
	}

	public int getLength() {
		return this.length;
	}

	public int getSize() {
		return this.width * this.length;
	}

	public void toogleMeasurement() {
		if (inFeet) {
			widthinm = this.width * 0.3048;
			lengthinm = this.length * 0.3048;

			inFeet = false;
			inMeters = true;
		} 
		else {			
			inFeet = true;
			inMeters = false;
		}

	}

	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Unit other = (Unit) obj;
		return (this.function == other.function) && (this.getSize() == other.getSize());
	}

	public String toString() {
		if (inFeet == true) {
			finalString = "A unit of " + this.width * this.length + " square feet (" + this.width + "' wide and "
					+ this.length + "' long) functioning as " + function;
		} else {
			finalString = "A unit of " + String.format("%.2f", widthinm * lengthinm) + " square meters ("
					+ String.format("%.2f", widthinm) + " m wide and " + String.format("%.2f", lengthinm)
					+ " m long) functioning as " + function;
		}
		return finalString;
	}

}
