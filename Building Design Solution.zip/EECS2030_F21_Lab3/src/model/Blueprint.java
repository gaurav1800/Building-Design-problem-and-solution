package model;

public class Blueprint {

	private String finalString;

	private int numOfFloors;
	private int addedFloors;
	private Floor[] floors;

	public Blueprint(Blueprint blueprint) {
		numOfFloors = blueprint.numOfFloors;
		floors = new Floor[numOfFloors];
		addedFloors = blueprint.addedFloors;
		for (int x = 0; x < addedFloors; x++) {
			floors[x] = new Floor(blueprint.floors[x]);
		}
	}

	public Blueprint() {
		// do nothing; just to initialize the variables to their default values
	}

	public Blueprint(int numOfFloors) {
		this.numOfFloors = numOfFloors;
		floors = new Floor[numOfFloors];
		addedFloors = 0;
	}

	public void addFloorPlan(Floor floor) {
		floors[addedFloors] = new Floor(floor);
		addedFloors++;
	}

	public Floor[] getFloors() {
		Floor[] currentFloors = new Floor[addedFloors];
		for (int x = 0; x < addedFloors; x++) {
			currentFloors[x] = floors[x];
		}
		return currentFloors;
	}

	public String toString() {
		double addedFloors = (double) this.addedFloors;
		double numOfFloors = (double) this.numOfFloors;
		finalString = String.format("%.1f", ((addedFloors / numOfFloors) * 100))
				+ " percents of building blueprint completed (" + this.addedFloors + " out of " + this.numOfFloors
				+ " floors)";
		return finalString;
	}

}
